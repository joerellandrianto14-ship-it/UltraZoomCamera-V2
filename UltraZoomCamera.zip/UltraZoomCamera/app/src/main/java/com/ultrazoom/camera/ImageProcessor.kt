package com.ultrazoom.camera

import android.graphics.Bitmap
import android.graphics.Matrix
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Software side of the zoom pipeline.
 *
 * The sensor/HAL zoom is used as far as the camera allows; anything beyond that
 * ("software zoom") is done here: crop the centre of the frame, upscale it in
 * steps, then apply an unsharp mask to win back perceived detail.
 */
object ImageProcessor {

    private const val MAX_OUTPUT_PIXELS = 8_000_000

    /** Rotate to upright and crop the centre 1/soft of the frame. */
    fun rotateAndCrop(src: Bitmap, rotationDegrees: Int, soft: Float): Bitmap {
        var bmp = src
        if (rotationDegrees != 0) {
            val m = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            bmp = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            if (bmp !== src) src.recycle()
        }
        if (soft <= 1.001f) return bmp
        val cw = max(32, (bmp.width / soft).toInt())
        val ch = max(32, (bmp.height / soft).toInt())
        val x = (bmp.width - cw) / 2
        val y = (bmp.height - ch) / 2
        val cropped = Bitmap.createBitmap(bmp, x, y, cw, ch)
        if (cropped !== bmp) bmp.recycle()
        return cropped
    }

    /**
     * Sharpness score (variance of a Laplacian) over the centre of the frame.
     * Used to pick the sharpest frame of a burst ("lucky imaging").
     */
    fun sharpness(bmp: Bitmap): Double {
        val sw = min(bmp.width, 512)
        val sh = min(bmp.height, 512)
        val x0 = (bmp.width - sw) / 2
        val y0 = (bmp.height - sh) / 2
        val px = IntArray(sw * sh)
        bmp.getPixels(px, 0, sw, x0, y0, sw, sh)
        val g = FloatArray(sw * sh) { i ->
            val c = px[i]
            0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF)
        }
        var sum = 0.0
        var sumSq = 0.0
        var n = 0
        for (y in 1 until sh - 1) {
            for (x in 1 until sw - 1) {
                val i = y * sw + x
                val l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - sw] - g[i + sw]
                sum += l
                sumSq += l * l
                n++
            }
        }
        if (n == 0) return 0.0
        val mean = sum / n
        return sumSq / n - mean * mean
    }

    /**
     * Upscale a cropped frame to [fullW] x [fullH] (capped to ~8 MP) and sharpen it.
     * [soft] is the software zoom factor that produced the crop.
     */
    fun upscaleAndSharpen(cropped: Bitmap, fullW: Int, fullH: Int, soft: Float): Bitmap {
        if (soft <= 1.001f) return cropped

        val cap = min(1f, sqrt(MAX_OUTPUT_PIXELS.toFloat() / (fullW.toFloat() * fullH)))
        val tw = max(cropped.width, (fullW * cap).toInt())
        val th = max(cropped.height, (fullH * cap).toInt())

        // Step-wise upscale (<= 1.6x per step) keeps bilinear filtering from smearing.
        var cur = cropped
        while (cur.width * 1.6f < tw) {
            val next = Bitmap.createScaledBitmap(
                cur, (cur.width * 1.6f).toInt(), (cur.height * 1.6f).toInt(), true
            )
            if (cur !== cropped) cur.recycle()
            cur = next
        }
        val scaled = if (cur.width != tw || cur.height != th)
            Bitmap.createScaledBitmap(cur, tw, th, true) else cur
        if (cur !== scaled && cur !== cropped) cur.recycle()
        if (scaled !== cropped) cropped.recycle()

        val amount = min(1.3f, 0.5f + 0.17f * ln(soft))
        return unsharp(scaled, amount)
    }

    /** Unsharp mask: out = src + amount * (src - blurred), with blur from a down/up-scale. */
    private fun unsharp(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val small = Bitmap.createScaledBitmap(src, max(1, w / 4), max(1, h / 4), true)
        val blurred = Bitmap.createScaledBitmap(small, w, h, true)
        small.recycle()

        val a = IntArray(w * h)
        val b = IntArray(w * h)
        src.getPixels(a, 0, w, 0, 0, w, h)
        blurred.getPixels(b, 0, w, 0, 0, w, h)
        blurred.recycle()

        for (i in a.indices) {
            val p = a[i]
            val q = b[i]
            val r = clamp(((p shr 16) and 0xFF) + amount * (((p shr 16) and 0xFF) - ((q shr 16) and 0xFF)))
            val g = clamp(((p shr 8) and 0xFF) + amount * (((p shr 8) and 0xFF) - ((q shr 8) and 0xFF)))
            val bl = clamp((p and 0xFF) + amount * ((p and 0xFF) - (q and 0xFF)))
            a[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
        val out = if (src.isMutable) src else src.copy(Bitmap.Config.ARGB_8888, true)
        out.setPixels(a, 0, w, 0, 0, w, h)
        if (out !== src) src.recycle()
        return out
    }

    private fun clamp(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else v.toInt()
}
