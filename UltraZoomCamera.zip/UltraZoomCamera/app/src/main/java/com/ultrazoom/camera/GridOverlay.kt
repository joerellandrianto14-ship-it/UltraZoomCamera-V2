package com.ultrazoom.camera

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/** Transparent layer on top of the preview: rule-of-thirds grid, focus ring, pinch + tap handling. */
class GridOverlay @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var showGrid = false
        set(value) { field = value; invalidate() }

    /** Called with the per-event pinch scale factor (>1 = fingers spreading). */
    var onPinch: ((Float) -> Unit)? = null

    /** Called with the tap position in this view's coordinates. */
    var onTap: ((Float, Float) -> Unit)? = null

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(110, 255, 255, 255)
        strokeWidth = 1.5f
    }
    private val focusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFEB3B")
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private var fx = -1f
    private var fy = -1f
    private var focusProgress = 1f // 0..1, 1 = hidden

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                onPinch?.invoke(detector.scaleFactor)
                return true
            }
        })

    private val tapDetector = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                onTap?.invoke(e.x, e.y)
                return true
            }
        })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(event)
        return true
    }

    fun showFocus(x: Float, y: Float) {
        fx = x
        fy = y
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1200
            addUpdateListener { focusProgress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (showGrid) {
            val w = width.toFloat()
            val h = height.toFloat()
            for (i in 1..2) {
                canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, gridPaint)
                canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, gridPaint)
            }
        }
        if (focusProgress < 1f && fx >= 0f) {
            focusPaint.alpha = (255 * (1f - focusProgress)).toInt()
            val r = 90f - 30f * minOf(1f, focusProgress * 4f)
            canvas.drawCircle(fx, fy, r, focusPaint)
        }
    }
}
