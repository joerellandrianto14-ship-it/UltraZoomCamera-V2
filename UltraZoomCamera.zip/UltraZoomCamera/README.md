# UltraZoom Camera (Android, Kotlin + CameraX)

Zoom 0.5x → 200x (pinch, log slider, presets 1x/2x/5x/10x/30x/50x/100x/200x).

## Build
- Android Studio: File > Open this folder > Run (minSdk 29).
- Or push to GitHub: Actions > "Build APK" produces app-debug.apk as an artifact.

## How zoom works
total zoom = sensor/HAL zoom (CameraX, up to the phone's max, uses telephoto lens on multi-camera phones)
           × software zoom (centre crop + stepwise upscale + unsharp mask, applied to the saved photo;
             live preview is scaled to match).

## Features
Tap-to-focus, exposure compensation, flash (off/auto/on), timer (3/10s), grid, front/back,
volume-key shutter, "BEST×5" lucky-imaging burst (shoots 5 frames, keeps the sharpest),
saves JPEG to Pictures/UltraZoom.
