package com.ultrazoom.camera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.ultrazoom.camera.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow

class MainActivity : AppCompatActivity() {

    companion object {
        /** Total zoom ceiling (sensor/HAL zoom + software zoom). Requirement was >= 100x. */
        const val MAX_TOTAL_ZOOM = 200f
        private val PRESETS = floatArrayOf(0.5f, 1f, 2f, 5f, 10f, 30f, 50f, 100f, 200f)
        private const val BURST_FRAMES = 5
    }

    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val uiExecutor by lazy { ContextCompat.getMainExecutor(this) }

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK

    // Zoom state: total = hardware (sensor/HAL) zoom * software (crop) zoom
    private var total = 1f
    private var minTotal = 1f
    private var hwMax = 1f
    private var lastHw = -1f
    private var seekFromUser = true

    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var timerSec = 0
    private var lucky = false
    private var busy = false
    private var evLower = 0
    private var evStep = 0f

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else {
            Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        // COMPATIBLE (TextureView) so we can scale the preview for software zoom;
        // FIT_CENTER so the preview matches exactly what ends up in the saved photo.
        b.preview.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        b.preview.scaleType = PreviewView.ScaleType.FIT_CENTER

        b.overlay.onPinch = { f -> applyZoom(total * f.pow(1.6f)) }
        b.overlay.onTap = { x, y -> tapToFocus(x, y) }

        b.zoomSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser && seekFromUser) {
                    applyZoom(minTotal * (MAX_TOTAL_ZOOM / minTotal).pow(p / 1000f))
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        b.evSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                val idx = p + evLower
                camera?.cameraControl?.setExposureCompensationIndex(idx)
                b.evLabel.text = String.format(Locale.US, "%+.1f", idx * evStep)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        b.btnFlash.setOnClickListener { cycleFlash() }
        b.btnTimer.setOnClickListener {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            b.btnTimer.text = if (timerSec == 0) "TIMER OFF" else "TIMER ${timerSec}s"
        }
        b.btnLucky.setOnClickListener {
            lucky = !lucky
            b.btnLucky.text = if (lucky) "BEST×$BURST_FRAMES ON" else "BEST×$BURST_FRAMES OFF"
        }
        b.btnGrid.setOnClickListener { b.overlay.showGrid = !b.overlay.showGrid }
        b.btnFlip.setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            total = 1f
            bindCamera()
        }
        b.shutter.setOnClickListener { onShutter() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) startCamera() else permission.launch(Manifest.permission.CAMERA)
    }

    // ---------------------------------------------------------------- camera

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            bindCamera()
        }, uiExecutor)
    }

    private fun bindCamera() {
        val p = provider ?: return
        p.unbindAll()
        camera?.cameraInfo?.zoomState?.removeObservers(this)

        val preview = Preview.Builder().build().also { it.setSurfaceProvider(b.preview.surfaceProvider) }
        val capture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(flashMode)
            .build()
        imageCapture = capture

        val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        val cam = try {
            p.bindToLifecycle(this, selector, preview, capture)
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open camera: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        camera = cam
        lastHw = -1f

        cam.cameraInfo.zoomState.observe(this) { zs ->
            val changed = zs.minZoomRatio != minTotal || zs.maxZoomRatio != hwMax
            minTotal = zs.minZoomRatio
            hwMax = zs.maxZoomRatio
            if (changed || lastHw < 0f) {
                buildPresets()
                applyZoom(total.coerceAtLeast(minTotal))
            }
        }

        val ev = cam.cameraInfo.exposureState
        if (ev.isExposureCompensationSupported) {
            evLower = ev.exposureCompensationRange.lower
            evStep = ev.exposureCompensationStep.toFloat()
            b.evSeek.max = ev.exposureCompensationRange.upper - evLower
            b.evSeek.progress = -evLower
            b.evSeek.isEnabled = true
        } else {
            b.evSeek.isEnabled = false
        }
    }

    /** Apply a total zoom: hardware zoom up to its max, the remainder as a software crop. */
    private fun applyZoom(requested: Float) {
        total = requested.coerceIn(minTotal, MAX_TOTAL_ZOOM)
        val hw = total.coerceIn(minTotal, maxOf(minTotal, hwMax))
        if (abs(hw - lastHw) > 0.005f) {
            camera?.cameraControl?.setZoomRatio(hw)
            lastHw = hw
        }
        val soft = total / hw
        b.preview.scaleX = soft
        b.preview.scaleY = soft

        val text = if (soft > 1.01f)
            String.format(Locale.US, "%.1f×  (sensor %.1f× + digital %.1f×)", total, hw, soft)
        else String.format(Locale.US, "%.1f×", total)
        b.hud.text = if (total >= 30f) "$text\nUse a tripod / brace the phone" else text

        seekFromUser = false
        b.zoomSeek.progress =
            (ln(total / minTotal) / ln(MAX_TOTAL_ZOOM / minTotal) * 1000f).toInt().coerceIn(0, 1000)
        seekFromUser = true
    }

    private fun softZoom(): Float {
        val hw = total.coerceIn(minTotal, maxOf(minTotal, hwMax))
        return total / hw
    }

    private fun buildPresets() {
        b.presets.removeAllViews()
        for (z in PRESETS) {
            if (z < minTotal - 0.01f || z > MAX_TOTAL_ZOOM) continue
            val tv = TextView(this).apply {
                text = if (z < 1f) "${z}×" else "${z.toInt()}×"
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                setBackgroundResource(R.drawable.bg_chip)
                setPadding(26, 14, 26, 14)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(8, 8, 8, 8) }
                setOnClickListener { applyZoom(z) }
            }
            b.presets.addView(tv)
        }
    }

    private fun tapToFocus(x: Float, y: Float) {
        val cam = camera ?: return
        // The preview view is scaled around its centre for software zoom; undo that.
        val soft = softZoom()
        val cx = b.preview.width / 2f
        val cy = b.preview.height / 2f
        val px = cx + (x - cx) / soft
        val py = cy + (y - cy) / soft
        val point = b.preview.meteringPointFactory.createPoint(px, py)
        cam.cameraControl.startFocusAndMetering(
            FocusMeteringAction.Builder(point).setAutoCancelDuration(4, TimeUnit.SECONDS).build()
        )
        b.overlay.showFocus(x, y)
    }

    private fun cycleFlash() {
        flashMode = when (flashMode) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flashMode
        b.btnFlash.text = when (flashMode) {
            ImageCapture.FLASH_MODE_AUTO -> "FLASH AUTO"
            ImageCapture.FLASH_MODE_ON -> "FLASH ON"
            else -> "FLASH OFF"
        }
    }

    // --------------------------------------------------------------- capture

    private fun onShutter() {
        if (busy) return
        busy = true
        b.shutter.alpha = 0.5f
        countdown(timerSec)
    }

    private fun countdown(n: Int) {
        if (n <= 0) {
            b.countdown.visibility = View.GONE
            startCapture()
            return
        }
        b.countdown.visibility = View.VISIBLE
        b.countdown.text = n.toString()
        handler.postDelayed({ countdown(n - 1) }, 1000)
    }

    private class Best(var bmp: Bitmap? = null, var score: Double = -1.0, var fullW: Int = 0, var fullH: Int = 0)

    private fun startCapture() {
        val soft = softZoom()
        val frames = if (lucky) BURST_FRAMES else 1
        grab(frames, soft, Best())
    }

    private fun grab(remaining: Int, soft: Float, best: Best) {
        val capture = imageCapture ?: return finishCapture(null)
        capture.takePicture(worker, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    val raw = image.toBitmap()
                    image.close()
                    // Record the full upright frame size before cropping.
                    val upright = rot == 90 || rot == 270
                    best.fullW = if (upright) raw.height else raw.width
                    best.fullH = if (upright) raw.width else raw.height

                    val cropped = ImageProcessor.rotateAndCrop(raw, rot, soft)
                    val score = if (lucky) ImageProcessor.sharpness(cropped) else 0.0
                    if (best.bmp == null || score > best.score) {
                        best.bmp?.recycle()
                        best.bmp = cropped
                        best.score = score
                    } else cropped.recycle()
                } catch (t: Throwable) {
                    image.close()
                    runOnUiThread { toast("Capture failed: ${t.message}") }
                    return finishCapture(null)
                }
                if (remaining > 1) uiExecutor.execute { grab(remaining - 1, soft, best) }
                else finishFrames(soft, best)
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { toast("Capture failed: ${exception.message}") }
                finishCapture(null)
            }
        })
    }

    private fun finishFrames(soft: Float, best: Best) {
        worker.execute {
            try {
                val src = best.bmp ?: return@execute finishCapture(null)
                val out = ImageProcessor.upscaleAndSharpen(src, best.fullW, best.fullH, soft)
                finishCapture(save(out))
                out.recycle()
            } catch (t: Throwable) {
                runOnUiThread { toast("Processing failed: ${t.message}") }
                finishCapture(null)
            }
        }
    }

    private fun save(bmp: Bitmap): Boolean {
        val name = "UZ_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UltraZoom")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        return true
    }

    private fun finishCapture(saved: Boolean?) {
        runOnUiThread {
            busy = false
            b.shutter.alpha = 1f
            if (saved == true) toast("Saved to Pictures/UltraZoom")
            else if (saved == false) toast("Could not save photo")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            onShutter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        worker.shutdown()
    }
}
